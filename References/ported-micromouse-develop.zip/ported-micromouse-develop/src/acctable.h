/*
 * acctable.h
 *
 *  Created on: 5 Aug 2016
 *      Author: peterharrison
 */

#ifndef ACCTABLE_H_
#define ACCTABLE_H_


#define SPEED_TABLE_END 1023
unsigned int accTable(int speed);

#endif /* ACCTABLE_H_ */
