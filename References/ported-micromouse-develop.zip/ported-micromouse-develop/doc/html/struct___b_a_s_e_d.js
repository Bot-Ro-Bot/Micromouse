var struct___b_a_s_e_d =
[
    [ "_BASED", "struct___b_a_s_e_d.html#ad245ef70c87f1b0680451c69e84d9a86", null ],
    [ "base", "struct___b_a_s_e_d.html#a2d2f682a027ec75d3c5c3e365d9325f0", null ],
    [ "val", "struct___b_a_s_e_d.html#a9aa9980a497acaa8856a0d0572f13191", null ]
];