var hardware_8cpp =
[
    [ "hardwareInit", "hardware_8cpp.html#aa046f9b9b030ee23fa45e603100f9292", null ],
    [ "redirectPrintf", "hardware_8cpp.html#aa8f77e57426ff79253851fb5129884d7", null ],
    [ "debug", "hardware_8cpp.html#a240057be01b20583a37c2e4d64863a03", null ],
    [ "nullConsole", "hardware_8cpp.html#acbd7d331510147cef533da452125b6ba", null ]
];