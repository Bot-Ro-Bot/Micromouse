var hierarchy =
[
    [ "_BASED", "struct___b_a_s_e_d.html", null ],
    [ "_FILL", "struct___f_i_l_l.html", null ],
    [ "_JUSTIFY", "struct___j_u_s_t_i_f_y.html", null ],
    [ "_TIME", "struct___t_i_m_e.html", null ],
    [ "Mouse", "class_mouse.html", null ],
    [ "Queue< item_t >", "class_queue.html", null ],
    [ "sensors", "classsensors.html", null ],
    [ "Stream", null, [
      [ "NullSerial", "class_null_serial.html", null ]
    ] ],
    [ "test", "classtest.html", null ],
    [ "ui", "classui.html", null ]
];