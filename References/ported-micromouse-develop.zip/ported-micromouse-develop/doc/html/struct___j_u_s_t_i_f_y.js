var struct___j_u_s_t_i_f_y =
[
    [ "_JUSTIFY", "struct___j_u_s_t_i_f_y.html#af0935dea684a102a57e75f44d8c8d063", null ],
    [ "val", "struct___j_u_s_t_i_f_y.html#a34cfd141afbb9e8651a736f5b4866256", null ],
    [ "width", "struct___j_u_s_t_i_f_y.html#ad1e55c8a95a998cb9beeafcb8f1ab774", null ]
];