var annotated_dup =
[
    [ "_BASED", "struct___b_a_s_e_d.html", "struct___b_a_s_e_d" ],
    [ "_FILL", "struct___f_i_l_l.html", "struct___f_i_l_l" ],
    [ "_JUSTIFY", "struct___j_u_s_t_i_f_y.html", "struct___j_u_s_t_i_f_y" ],
    [ "_TIME", "struct___t_i_m_e.html", "struct___t_i_m_e" ],
    [ "Mouse", "class_mouse.html", "class_mouse" ],
    [ "NullSerial", "class_null_serial.html", "class_null_serial" ],
    [ "Queue", "class_queue.html", "class_queue" ],
    [ "sensors", "classsensors.html", null ],
    [ "test", "classtest.html", null ],
    [ "ui", "classui.html", "classui" ]
];