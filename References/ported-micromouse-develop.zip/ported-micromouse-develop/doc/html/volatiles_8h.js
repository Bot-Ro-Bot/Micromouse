var volatiles_8h =
[
    [ "ABS_DIFF", "volatiles_8h.html#ad08b4f3a3e02f3a2eefa2bb5807fce81", null ],
    [ "DIFF", "volatiles_8h.html#a978c90d4e303defce37c13f3d16b6e3d", null ],
    [ "getVolatile", "volatiles_8h.html#a8202f8521065bb35f28709c12c8330fa", null ],
    [ "GT", "volatiles_8h.html#ac772379b06771f7bfa86d33c423fbb2d", null ],
    [ "GTE", "volatiles_8h.html#af21af202bc52b91bb70ea6ddd1cf04ce", null ],
    [ "LT", "volatiles_8h.html#acbf5e1a27ea1789dacfb01fc8945ec2b", null ],
    [ "LTE", "volatiles_8h.html#aec633ef66b8c430bff1728b0f2c441b4", null ],
    [ "NE", "volatiles_8h.html#ac7f31e988a3f437751d527d7f5ebdc4e", null ],
    [ "setVolatile", "volatiles_8h.html#a6e208ed724d1bde9d945f1e543e8fa92", null ]
];