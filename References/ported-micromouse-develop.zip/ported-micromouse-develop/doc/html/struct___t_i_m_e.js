var struct___t_i_m_e =
[
    [ "_TIME", "struct___t_i_m_e.html#a28542a9b01a7592c816d0a9fdae1a25d", null ],
    [ "hour", "struct___t_i_m_e.html#a7f52e31c2ee006f9dc13fed0b2baecd3", null ],
    [ "minu", "struct___t_i_m_e.html#a04bf75c7c9bd15b48d39c7364acc4896", null ],
    [ "sec", "struct___t_i_m_e.html#a386f863c4d368f8d0556a4c4b700b018", null ]
];