var motion_8cpp =
[
    [ "forward", "motion_8cpp.html#a57ad0eca5e7c09ec884cd77c7c281534", null ],
    [ "move", "motion_8cpp.html#aec4465a74ff198419e3802dede4858d6", null ],
    [ "spin", "motion_8cpp.html#af4c1476a7d7013799014255708565ebc", null ],
    [ "startForward", "motion_8cpp.html#adc5c2ba4b47c6373d09effaa511e7eba", null ],
    [ "startReverse", "motion_8cpp.html#ad72b74ab0dc25b9d465c49acc6e6c2b5", null ],
    [ "turnIP180", "motion_8cpp.html#a78dbd373fcd4c4e757bbd88773ea3e8c", null ],
    [ "turnIP90L", "motion_8cpp.html#a2e078c59b94a29d48c961fcf9128214a", null ],
    [ "turnIP90R", "motion_8cpp.html#a8e1a5bd047b468d2b32f5b2d6bccf520", null ],
    [ "turnSmooth", "motion_8cpp.html#a057628c1cb4b6fbb9007cba70846d7aa", null ],
    [ "turnSS90L", "motion_8cpp.html#a06607256f4de72ed82e041871e0a9a80", null ],
    [ "turnSS90R", "motion_8cpp.html#ac9c13db6497cf9a7e970c7aa18b4afa8", null ]
];