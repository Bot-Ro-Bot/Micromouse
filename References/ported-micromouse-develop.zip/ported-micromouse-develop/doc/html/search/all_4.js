var searchData=
[
  ['debouncepin',['debouncePin',['../ui_8cpp.html#a159cccde9fee27a51a2dabd3bebaead0',1,'debouncePin(unsigned char pin):&#160;ui.cpp'],['../ui_8h.html#a159cccde9fee27a51a2dabd3bebaead0',1,'debouncePin(unsigned char pin):&#160;ui.cpp']]],
  ['debounceticks',['debounceTicks',['../ui_8cpp.html#a037e4fba90dc94d96d5013d5dbf99748',1,'ui.cpp']]],
  ['debug',['debug',['../hardware_8cpp.html#a240057be01b20583a37c2e4d64863a03',1,'debug():&#160;hardware.cpp'],['../hardware_8h.html#a240057be01b20583a37c2e4d64863a03',1,'debug():&#160;hardware.cpp']]],
  ['deg',['DEG',['../parameters_8h.html#a136e40fed1fee72b1509db90e66a9b29',1,'parameters.h']]],
  ['diag_5fthreshold',['DIAG_THRESHOLD',['../parameters_8h.html#ae5cabac7bd63043a9f2d14e3ab9acc82',1,'parameters.h']]],
  ['diff',['DIFF',['../volatiles_8h.html#a978c90d4e303defce37c13f3d16b6e3d',1,'volatiles.h']]],
  ['digitalwritefast_2eh',['digitalwritefast.h',['../digitalwritefast_8h.html',1,'']]],
  ['dirchars',['dirChars',['../ui_8cpp.html#a7ace3a5ca91cbe615148024ac19a0516',1,'ui.cpp']]],
  ['directiontosmallest',['directionToSmallest',['../maze_8cpp.html#a453f919ea8d3041dfdec6f916355cbed',1,'directionToSmallest(unsigned char cell, unsigned char startDirection):&#160;maze.cpp'],['../maze_8h.html#a453f919ea8d3041dfdec6f916355cbed',1,'directionToSmallest(unsigned char cell, unsigned char startDirection):&#160;maze.cpp']]],
  ['dirl',['DIRL',['../hardware_8h.html#af64121d024f9c395c8f6ee138d0e55e3',1,'hardware.h']]],
  ['dirletters',['dirLetters',['../ui_8cpp.html#a2ecc35f75676802092e53416c2e14bf6',1,'dirLetters():&#160;ui.cpp'],['../ui_8h.html#a2ecc35f75676802092e53416c2e14bf6',1,'dirLetters():&#160;ui.cpp']]],
  ['dirr',['DIRR',['../hardware_8h.html#ae24aa3592801b894fa7b04c06d008e64',1,'hardware.h']]],
  ['doalignment',['doAlignment',['../navigator_8cpp.html#a4cd7ca3957f507ec79e5d9361e1bc61a',1,'doAlignment():&#160;navigator.cpp'],['../navigator_8h.html#a4cd7ca3957f507ec79e5d9361e1bc61a',1,'doAlignment():&#160;navigator.cpp']]],
  ['dobutton',['doButton',['../ui_8cpp.html#ae69d2f907d090a7972a5c060980bc381',1,'doButton():&#160;ui.cpp'],['../ui_8h.html#ae69d2f907d090a7972a5c060980bc381',1,'doButton():&#160;ui.cpp']]],
  ['docli',['doCLI',['../ui_8cpp.html#a332a92a6c127cb22c32db6d1c10e589f',1,'doCLI():&#160;ui.cpp'],['../ui_8h.html#a332a92a6c127cb22c32db6d1c10e589f',1,'doCLI():&#160;ui.cpp']]],
  ['dofec',['doFEC',['../navigator_8cpp.html#a1fd589e315a86bf83b351f61926968f5',1,'navigator.cpp']]],
  ['dtob',['DtoB',['../maze_8h.html#a320d8e5a73063949e7b8ac45a65467c1',1,'maze.h']]],
  ['dtol',['DtoL',['../maze_8h.html#a7b64792c24ddf0d48deb22ac031ac3a2',1,'maze.h']]],
  ['dtor',['DtoR',['../maze_8h.html#a1e130693f199a2aeb6ccdfb7532e3613',1,'maze.h']]]
];
