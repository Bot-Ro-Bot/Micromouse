var searchData=
[
  ['read',['read',['../class_null_serial.html#ae961938e969e842bf4194fffb0a8d320',1,'NullSerial::read()'],['../ui_8cpp.html#a146d72b5db640aa626ddf3ca7e980463',1,'read():&#160;ui.cpp']]],
  ['redirectprintf',['redirectPrintf',['../hardware_8cpp.html#aa8f77e57426ff79253851fb5129884d7',1,'hardware.cpp']]]
];
