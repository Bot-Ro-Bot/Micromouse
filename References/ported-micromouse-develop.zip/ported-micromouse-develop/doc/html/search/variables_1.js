var searchData=
[
  ['base',['base',['../struct___b_a_s_e_d.html#a2d2f682a027ec75d3c5c3e365d9325f0',1,'_BASED']]]
];
