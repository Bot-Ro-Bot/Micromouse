var searchData=
[
  ['debouncepin',['debouncePin',['../ui_8cpp.html#a159cccde9fee27a51a2dabd3bebaead0',1,'debouncePin(unsigned char pin):&#160;ui.cpp'],['../ui_8h.html#a159cccde9fee27a51a2dabd3bebaead0',1,'debouncePin(unsigned char pin):&#160;ui.cpp']]],
  ['diff',['DIFF',['../volatiles_8h.html#a978c90d4e303defce37c13f3d16b6e3d',1,'volatiles.h']]],
  ['directiontosmallest',['directionToSmallest',['../maze_8cpp.html#a453f919ea8d3041dfdec6f916355cbed',1,'directionToSmallest(unsigned char cell, unsigned char startDirection):&#160;maze.cpp'],['../maze_8h.html#a453f919ea8d3041dfdec6f916355cbed',1,'directionToSmallest(unsigned char cell, unsigned char startDirection):&#160;maze.cpp']]],
  ['doalignment',['doAlignment',['../navigator_8cpp.html#a4cd7ca3957f507ec79e5d9361e1bc61a',1,'doAlignment():&#160;navigator.cpp'],['../navigator_8h.html#a4cd7ca3957f507ec79e5d9361e1bc61a',1,'doAlignment():&#160;navigator.cpp']]],
  ['dobutton',['doButton',['../ui_8cpp.html#ae69d2f907d090a7972a5c060980bc381',1,'doButton():&#160;ui.cpp'],['../ui_8h.html#ae69d2f907d090a7972a5c060980bc381',1,'doButton():&#160;ui.cpp']]],
  ['docli',['doCLI',['../ui_8cpp.html#a332a92a6c127cb22c32db6d1c10e589f',1,'doCLI():&#160;ui.cpp'],['../ui_8h.html#a332a92a6c127cb22c32db6d1c10e589f',1,'doCLI():&#160;ui.cpp']]],
  ['dofec',['doFEC',['../navigator_8cpp.html#a1fd589e315a86bf83b351f61926968f5',1,'navigator.cpp']]]
];
