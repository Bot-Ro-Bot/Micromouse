var searchData=
[
  ['sensorgetfrontdistance',['sensorGetFrontDistance',['../sensors_8cpp.html#a7b144551eca2dce85f04a79c8f2af62e',1,'sensorGetFrontDistance():&#160;sensors.cpp'],['../sensors_8h.html#a7b144551eca2dce85f04a79c8f2af62e',1,'sensorGetFrontDistance():&#160;sensors.cpp']]],
  ['sensorgetfrontsteering',['sensorGetFrontSteering',['../sensors_8cpp.html#a8b557f031ac784c585d38bfe12c60684',1,'sensorGetFrontSteering(int distance):&#160;sensors.cpp'],['../sensors_8h.html#a8b557f031ac784c585d38bfe12c60684',1,'sensorGetFrontSteering(int distance):&#160;sensors.cpp']]],
  ['sensorsdisable',['sensorsDisable',['../sensors_8cpp.html#a8857f68f3fa4c5f5c3fb1ba156cfd689',1,'sensorsDisable():&#160;sensors.cpp'],['../sensors_8h.html#a8857f68f3fa4c5f5c3fb1ba156cfd689',1,'sensorsDisable():&#160;sensors.cpp']]],
  ['sensorsenable',['sensorsEnable',['../sensors_8cpp.html#a811ab0d22bfcc1e9822a43aecf46c964',1,'sensorsEnable():&#160;sensors.cpp'],['../sensors_8h.html#a811ab0d22bfcc1e9822a43aecf46c964',1,'sensorsEnable():&#160;sensors.cpp']]],
  ['sensorsinit',['sensorsInit',['../sensors_8cpp.html#a6adea729ccf39058b9dead88f601ffac',1,'sensorsInit():&#160;sensors.cpp'],['../sensors_8h.html#a6adea729ccf39058b9dead88f601ffac',1,'sensorsInit():&#160;sensors.cpp']]],
  ['sensorupdate',['sensorUpdate',['../sensors_8cpp.html#a5d29546d6e72ac164ad42ab1136083fa',1,'sensorUpdate():&#160;sensors.cpp'],['../sensors_8h.html#a5d29546d6e72ac164ad42ab1136083fa',1,'sensorUpdate():&#160;sensors.cpp']]],
  ['setmicrostepmode',['setMicrostepMode',['../motors_8cpp.html#acc5eea97dee605576d0b3c72ac540956',1,'setMicrostepMode(int mode):&#160;motors.cpp'],['../motors_8h.html#acc5eea97dee605576d0b3c72ac540956',1,'setMicrostepMode(int mode):&#160;motors.cpp']]],
  ['setup',['setup',['../ported_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d',1,'ported.cpp']]],
  ['setvolatile',['setVolatile',['../volatiles_8h.html#a6e208ed724d1bde9d945f1e543e8fa92',1,'volatiles.h']]],
  ['sidesensorerror',['sideSensorError',['../navigator_8cpp.html#ac472036c2cd88c7bf8efdb98fd3ebfa4',1,'navigator.cpp']]],
  ['size',['size',['../class_queue.html#a94f5dcdb54e20807af1b2509d6b234e5',1,'Queue']]],
  ['spin',['spin',['../motion_8cpp.html#af4c1476a7d7013799014255708565ebc',1,'spin(long steps, int maxSpeed, int exitSpeed):&#160;motion.cpp'],['../motion_8h.html#af4c1476a7d7013799014255708565ebc',1,'spin(long steps, int maxSpeed, int exitSpeed):&#160;motion.cpp']]],
  ['startforward',['startForward',['../motion_8cpp.html#adc5c2ba4b47c6373d09effaa511e7eba',1,'startForward(int maxSpeed):&#160;motion.cpp'],['../motion_8h.html#adc5c2ba4b47c6373d09effaa511e7eba',1,'startForward(int maxSpeed):&#160;motion.cpp']]],
  ['startreverse',['startReverse',['../motion_8cpp.html#ad72b74ab0dc25b9d465c49acc6e6c2b5',1,'startReverse(int maxSpeed):&#160;motion.cpp'],['../motion_8h.html#ad72b74ab0dc25b9d465c49acc6e6c2b5',1,'startReverse(int maxSpeed):&#160;motion.cpp']]],
  ['stopandadjust',['stopAndAdjust',['../mouse_8cpp.html#a727461c72529d407fbf6a45820d59fef',1,'mouse.cpp']]],
  ['systick',['systick',['../systick_8cpp.html#a97814715be421745b4f6dc92c432d5d5',1,'systick():&#160;systick.cpp'],['../systick_8h.html#a97814715be421745b4f6dc92c432d5d5',1,'systick():&#160;systick.cpp']]],
  ['systickinit',['systickInit',['../systick_8cpp.html#a30308762843db17d7c7a66c6e21fb864',1,'systickInit(int frequency):&#160;systick.cpp'],['../systick_8h.html#a30308762843db17d7c7a66c6e21fb864',1,'systickInit(int frequency):&#160;systick.cpp']]]
];
