var searchData=
[
  ['deg',['DEG',['../parameters_8h.html#a136e40fed1fee72b1509db90e66a9b29',1,'parameters.h']]],
  ['diag_5fthreshold',['DIAG_THRESHOLD',['../parameters_8h.html#ae5cabac7bd63043a9f2d14e3ab9acc82',1,'parameters.h']]],
  ['dirl',['DIRL',['../hardware_8h.html#af64121d024f9c395c8f6ee138d0e55e3',1,'hardware.h']]],
  ['dirr',['DIRR',['../hardware_8h.html#ae24aa3592801b894fa7b04c06d008e64',1,'hardware.h']]]
];
