var searchData=
[
  ['val',['val',['../struct___b_a_s_e_d.html#a9aa9980a497acaa8856a0d0572f13191',1,'_BASED::val()'],['../struct___j_u_s_t_i_f_y.html#a34cfd141afbb9e8651a736f5b4866256',1,'_JUSTIFY::val()']]]
];
