#ifndef nodes_H
#define nodes_H
#include<wirish.h>



class Node {

   public:
   byte count;
   uint8_t infoByte;   //Walls(L,F,R), 4th bit khali aele lae:LOWER NIBBLE and 2-bit for nodetype,2-byte remaining path:HIGHER NIBBLE

    void NodeDetails();

    //count: for no. of times the node is visited [0,4]
    //POTENTIAL VALUES
    /*First, check whether or not the cell has been visited;
      Check where the walls are;
      Calculate the number of ways;
      Make a decision based on the available number of ways;
      Move between cells, check for closed loop paths and dead
      ends, and update cell variables;
      Finally, check if the destination cell has been reached.*/

};

#endif
