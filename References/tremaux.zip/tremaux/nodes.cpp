#include"nodes.h"
uint16_t distance[3];
uint16_t wallDistance[3];

void Node::NodeDetails() {
  count = 0;
  infoByte = 0;
  for (int i = 0; i < 3; infoByte += (distance[i] > wallDistance[i] ? 0x01 : 0), i++); //for walls: L=01,F=10;R=11 //milauna baki
  for (int i = 0; i < 3; infoByte += (distance[i] > wallDistance[i]) ? 0x50 : 0, i++); //for node type and path remaining : i=1|2|3 true=>not node 1way(1path remaining),
  //i=1&2|2&3|3&1 true=> 2way node(2path remaining), i=1&2&3 true=> 3way node(3path remaining) all false=>dead end

  //if(infoByte & 32 == 32) infoBit |= 64; //node or not

  /* int c = 0;
    for(int i = 0;i<3;c+=(distance[i]>wallDistance)?1:0,i++);
    infoBit |= (c<<4);//*/
}
